This game uses an Xbox controller

Move with the left stick

Aim and fire with the right stick